<?php

	$rawPostData = file_get_contents('php://input');
	$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
	$txt = $rawPostData;
	fwrite($myfile, $txt);
	fclose($myfile);
	
?>

