<?php
$MID='122000000000266';
$PSK='C8F40713FC553D8FFA8AD5F6CCD784E8C4201810BAAA6735BC22BB2E9237150E';
$url = "https://ipg.fomopay.net/api/orders/100500120220216395472769";
$headers = array(
	"Content-Type: application/json",
	"Authorization: Basic MTIyMDAwMDAwMDAwMjY2OkM4RjQwNzEzRkM1NTNEOEZGQThBRDVGNkNDRDc4NEU4QzQyMDE4MTBCQUFBNjczNUJDMjJCQjJFOTIzNzE1MEU="
);
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
echo $resp;
curl_close($curl);
$response = json_decode($resp);
echo "<pre>";
print_r($response);

echo $response->amount;

die;

?>


