<?php
$MID='122000000000266';
$PSK='C8F40713FC553D8FFA8AD5F6CCD784E8C4201810BAAA6735BC22BB2E9237150E';
echo base64_encode($MID.':'.$PSK);
echo "<br/>";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);	
$url = 'https://ipg.fomopay.net/api/orders';
$data = array(
    "mode" => "HOSTED",
	"subMid"=>"00000000",
    "orderNo" => "Order".rand(),
	"subject" => "Testing Order",
	"description" => "Testing Order",
	"amount" => "1.00",
	"currencyCode" => "SGD",
	"notifyUrl" => "https://waytoweb.info/fomopay/notify.php",
	"returnUrl" => "https://waytoweb.info/fomopay/success.php",
	"backUrl" => "https://waytoweb.info/fomopay/return.php",
	"sourceOfFunds"=>["CARD"],
);

$headers = array(
	"Content-Type: application/json",
	"Authorization: Basic MTIyMDAwMDAwMDAwMjY2OkM4RjQwNzEzRkM1NTNEOEZGQThBRDVGNkNDRDc4NEU4QzQyMDE4MTBCQUFBNjczNUJDMjJCQjJFOTIzNzE1MEU="
);

$postdata = json_encode($data);
$ch = curl_init($url); 
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$result = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);   //get status code
//echo $status_code;
echo "<pre>";
curl_close($ch);
$response = json_decode($result);
if(!empty($response)){
	
	header("Location:".$response->url);
}
?>


